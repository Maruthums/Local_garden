import React from "react";
import Navbar from './components/common/nav';
import Home from "./screen/main/home";

function App() {
  return (
    <div style={{
      backgroundColor:'#000000'
    }}>
      <Navbar />
    </div>
  );
}

export default App;
